# `financecv` LaTeX Package
LaTeX CV template for jobs in Finance and IT

| Example (caps) | Example (base) |
| -- | -- |
| ![Caps](examples/caps.jpg)| ![Base](examples/base.jpg)  |
